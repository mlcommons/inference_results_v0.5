#include <map>
#include <chrono>


namespace common {

	using ScheduleClock = std::chrono::system_clock;

}
